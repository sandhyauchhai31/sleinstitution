import React, { useState, useEffect } from 'react';
import { 
  Download, 
  Upload, 
  Eye, 
  EyeOff, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Database,
  FileText,
  Sparkles,
  RefreshCw,
  X,
  Printer,
  User,
  Phone,
  MapPin,
  Calendar,
  GraduationCap,
  Building
} from 'lucide-react';
import { db, collection, getDocs, setDoc, doc, deleteDoc } from '../firebase';

export default function ImportExportData() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDataTable, setShowDataTable] = useState(true);
  const [importing, setImporting] = useState(false);
  const [importStatus, setImportStatus] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedStudentForView, setSelectedStudentForView] = useState(null);

  // 1. Fetch Live Database Records matching exact requested fields
  const fetchStudents = async () => {
    setLoading(true);
    let loadedMap = new Map();

    // Check localStorage cache first
    try {
      const cached = JSON.parse(localStorage.getItem('sle_students_cache') || '[]');
      cached.forEach(item => {
        if (item.registrationNo || item.regNo || item.id) {
          const key = String(item.registrationNo || item.regNo || item.id);
          loadedMap.set(key, item);
        }
      });
    } catch (e) {}

    // Check Firestore 'students' collection
    if (db) {
      try {
        const snap = await getDocs(collection(db, 'students'));
        snap.forEach(docSnap => {
          const data = docSnap.data();
          const key = String(data.registrationNo || data.regNo || docSnap.id);
          loadedMap.set(key, { id: docSnap.id, ...data });
        });
      } catch (e) {}
    }

    const list = Array.from(loadedMap.values()).map((s, idx) => {
      const regNo = String(s.registrationNo || s.regNo || 202638001 + idx);
      const fId = String(s.franchiseeId || s.environmentId || s.centerCode || 'FR-2026-901');
      const name = String(s.fullName || s.name || s.studentName || 'Student Name');
      const mobile = String(s.contactNo || s.mobileNo || s.phone || 'N/A');
      const place = String(s.place || s.location || s.trustBranch || s.address || 'Athani');
      const cls = String(s.selectedClass || s.class || s.admissionClass || '10th');
      const date = String(s.createdDate || s.date || s.admissionDate || new Date().toISOString().split('T')[0]);

      return {
        ...s,
        registrationNo: regNo,
        franchiseeId: fId,
        fullName: name,
        mobileNo: mobile,
        place: place,
        selectedClass: cls,
        createdDate: date
      };
    });

    setStudents(list);
    setLoading(false);
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  // 2. Download CSV Excel Template Handler matching requested fields
  const handleDownloadTemplate = () => {
    const headers = [
      'REGISTRATION NO',
      'FRANCHISEE ID',
      'NAME',
      'MOBILE NO',
      'PLACE',
      'CLASS',
      'DATE'
    ];

    const sampleRow = [
      '202638001',
      'FR-2026-901',
      'Ananya Gowda',
      '9845012345',
      'Athani',
      '10th',
      '2026-08-25'
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), sampleRow.join(',')].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'sle_student_import_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 3. Export Active Database Records to CSV Excel matching requested fields
  const handleExportCSV = () => {
    if (students.length === 0) {
      alert('No student records available to export.');
      return;
    }

    const headers = [
      'REGISTRATION NO',
      'FRANCHISEE ID',
      'NAME',
      'MOBILE NO',
      'PLACE',
      'CLASS',
      'DATE'
    ];

    const rows = students.map(s => [
      `"${s.registrationNo}"`,
      `"${s.franchiseeId}"`,
      `"${s.fullName}"`,
      `"${s.mobileNo}"`,
      `"${s.place}"`,
      `"${s.selectedClass}"`,
      `"${s.createdDate}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sle_students_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 4. Handle Excel/CSV File Upload & Import
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setSelectedFile(file);
    setImporting(true);
    setImportStatus(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target.result;
        const lines = text.split(/\r\n|\n/);
        if (lines.length < 2) {
          setImportStatus({ type: 'error', message: 'The uploaded file appears to be empty.' });
          setImporting(false);
          return;
        }

        const newRecords = [];

        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          const values = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
          
          if (values.length >= 2) {
            const regNo = values[0] || String(202638000 + i);
            const fId = values[1] || 'FR-2026-901';
            const name = values[2] || `Student ${i}`;
            const mobile = values[3] || 'N/A';
            const place = values[4] || 'Athani';
            const cls = values[5] || '10th';
            const date = values[6] || new Date().toISOString().split('T')[0];

            const record = {
              id: `STUD-${regNo}`,
              registrationNo: regNo,
              regNo: regNo,
              appNumber: `SLE-2026-${regNo}`,
              franchiseeId: fId,
              fullName: name,
              name: name,
              contactNo: mobile,
              mobileNo: mobile,
              phone: mobile,
              place: place,
              location: place,
              trustBranch: place,
              selectedClass: cls,
              class: cls,
              admissionClass: cls,
              createdDate: date,
              date: date,
              paymentStatus: 'Paid',
              status: 'Approved',
              importedAt: new Date().toISOString()
            };
            newRecords.push(record);
          }
        }

        if (newRecords.length === 0) {
          setImportStatus({ type: 'error', message: 'No valid student rows found in uploaded file.' });
          setImporting(false);
          return;
        }

        // Save records to Firestore & localStorage
        try {
          const cached = JSON.parse(localStorage.getItem('sle_students_cache') || '[]');
          const updatedCache = [...newRecords, ...cached];
          localStorage.setItem('sle_students_cache', JSON.stringify(updatedCache));
          localStorage.setItem('sle_coaching_students_cache', JSON.stringify(updatedCache));
        } catch (e) {}

        if (db) {
          for (const rec of newRecords) {
            try {
              await setDoc(doc(db, 'students', rec.id), rec, { merge: true });
            } catch (err) {}
          }
        }

        setImportStatus({ type: 'success', message: `Successfully imported ${newRecords.length} student record(s)!` });
        fetchStudents();
      } catch (err) {
        console.error('File import error:', err);
        setImportStatus({ type: 'error', message: 'Error processing CSV file. Please verify column formatting.' });
      } finally {
        setImporting(false);
      }
    };

    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 py-8 px-4 sm:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Page Main Header Title */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight flex items-center justify-center gap-3">
            <FileSpreadsheet className="w-8 h-8 text-rose-600" />
            <span>Import/Export Data</span>
          </h1>
          <p className="text-sm font-semibold text-slate-600 max-w-xl mx-auto">
            Manage institutional student records. Upload bulk Excel/CSV data or export current database entries.
          </p>
        </div>

        {/* Top Import Controls Card */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-8 space-y-6">
          
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-200">
            
            {/* File Upload Selector Input */}
            <div className="w-full lg:w-auto flex flex-col sm:flex-row items-start sm:items-center gap-3">
              <label className="text-xs sm:text-sm font-black uppercase text-slate-700 tracking-wide shrink-0">
                To Upload Excel Sheet Choose File :
              </label>
              <input
                type="file"
                accept=".csv, .xlsx, .xls"
                onChange={handleFileUpload}
                disabled={importing}
                className="file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-extrabold file:bg-slate-900 file:text-white hover:file:bg-slate-800 text-xs text-slate-600 border border-slate-300 rounded-2xl p-1.5 w-full sm:w-auto cursor-pointer"
              />
            </div>

            {/* Download Template Action Button */}
            <div className="w-full lg:w-auto flex flex-col items-center lg:items-end gap-1.5 text-center lg:text-right">
              <button
                type="button"
                onClick={handleDownloadTemplate}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-rose-800 to-red-900 hover:from-rose-900 hover:to-red-950 text-white font-black text-xs sm:text-sm shadow-lg shadow-rose-900/20 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4 text-amber-300" />
                <span>Download Template</span>
              </button>
              <p className="text-[11px] font-semibold text-rose-700 max-w-sm">
                Please download the template first, fill in the required fields, and then upload the completed file.
              </p>
            </div>

          </div>

          {/* Import Status Alert Banner */}
          {importing && (
            <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-800 flex items-center gap-3 text-xs font-bold animate-pulse">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
              <span>Importing records into database...</span>
            </div>
          )}

          {importStatus && (
            <div className={`p-4 rounded-2xl border flex items-center gap-3 text-xs font-bold ${
              importStatus.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}>
              {importStatus.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              )}
              <span>{importStatus.message}</span>
            </div>
          )}

        </div>

        {/* Data Table Toggle Button */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => setShowDataTable(prev => !prev)}
            className="px-6 py-2.5 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-extrabold text-xs shadow-md active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
          >
            {showDataTable ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            <span>{showDataTable ? 'Hide Data' : 'Show Data'}</span>
          </button>

          {showDataTable && (
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleExportCSV}
                className="px-5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow transition flex items-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>Export CSV (Excel)</span>
              </button>
              
              <button
                type="button"
                onClick={fetchStudents}
                className="p-2.5 rounded-2xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 shadow-sm transition cursor-pointer"
                title="Refresh Records"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          )}
        </div>

        {/* Database Records Table Card matching exact requested columns */}
        {showDataTable && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-8 space-y-6 animate-in fade-in duration-200">
            
            <div className="text-center pb-2">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center justify-center gap-2">
                <Database className="w-6 h-6 text-sky-600" />
                <span>Data From Database</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1 font-medium">
                Total Records Loaded: <strong>{students.length}</strong>
              </p>
            </div>

            {/* Table Container */}
            <div className="overflow-x-auto rounded-2xl border border-slate-200/90 shadow-sm">
              <table className="w-full text-left text-xs font-sans">
                <thead className="bg-slate-100 text-slate-800 font-extrabold uppercase border-b border-slate-200 tracking-wider">
                  <tr>
                    <th className="px-4 py-3.5 whitespace-nowrap">REGISTRATION NO</th>
                    <th className="px-4 py-3.5 whitespace-nowrap">FRANCHISEE ID</th>
                    <th className="px-4 py-3.5 whitespace-nowrap">NAME</th>
                    <th className="px-4 py-3.5 whitespace-nowrap">MOBILE NO</th>
                    <th className="px-4 py-3.5 whitespace-nowrap">PLACE</th>
                    <th className="px-4 py-3.5 whitespace-nowrap">CLASS</th>
                    <th className="px-4 py-3.5 whitespace-nowrap">DATE</th>
                    <th className="px-4 py-3.5 text-center whitespace-nowrap">VIEW DETAILS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {loading ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-500">
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="w-5 h-5 animate-spin text-rose-600" />
                          <span>Loading Database Records...</span>
                        </div>
                      </td>
                    </tr>
                  ) : students.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-500 font-semibold">
                        No student admission records found.
                      </td>
                    </tr>
                  ) : (
                    students.map((s, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 transition-colors text-slate-800">
                        <td className="px-4 py-3.5 font-mono font-bold text-rose-600">{s.registrationNo}</td>
                        <td className="px-4 py-3.5 font-mono text-indigo-700 font-semibold">{s.franchiseeId}</td>
                        <td className="px-4 py-3.5 font-extrabold text-slate-900 uppercase">{s.fullName}</td>
                        <td className="px-4 py-3.5 font-mono font-semibold text-slate-700">{s.mobileNo}</td>
                        <td className="px-4 py-3.5 font-semibold text-slate-800">{s.place}</td>
                        <td className="px-4 py-3.5 font-bold text-purple-700">{s.selectedClass}</td>
                        <td className="px-4 py-3.5 font-mono text-slate-600">{s.createdDate}</td>
                        <td className="px-4 py-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => setSelectedStudentForView(s)}
                            className="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold border border-indigo-200 transition-all text-xs flex items-center justify-center gap-1.5 mx-auto cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5 text-indigo-600" />
                            <span>View Details</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

          </div>
        )}

      </div>

      {/* VIEW DETAILS MODAL */}
      {selectedStudentForView && (
        <div id="printable-record-modal" className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200 printable-modal">
          <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl p-6 sm:p-8 space-y-6 relative my-8">
            
            <button
              onClick={() => setSelectedStudentForView(null)}
              className="absolute right-6 top-6 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-200 pb-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center font-bold">
                <User className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-900">{selectedStudentForView.fullName}</h3>
                <p className="text-xs text-rose-600 font-mono font-bold">
                  Registration No: {selectedStudentForView.registrationNo}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="block text-[11px] font-bold text-slate-500 uppercase">Franchisee ID</span>
                <span className="font-extrabold text-indigo-600 font-mono text-sm">{selectedStudentForView.franchiseeId}</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="block text-[11px] font-bold text-slate-500 uppercase">Mobile Number</span>
                <span className="font-bold text-slate-800">{selectedStudentForView.mobileNo}</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="block text-[11px] font-bold text-slate-500 uppercase">Place / Branch</span>
                <span className="font-bold text-slate-800">{selectedStudentForView.place}</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="block text-[11px] font-bold text-slate-500 uppercase">Class / Course</span>
                <span className="font-bold text-purple-700">{selectedStudentForView.selectedClass}</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 sm:col-span-2">
                <span className="block text-[11px] font-bold text-slate-500 uppercase">Admission Date</span>
                <span className="font-semibold text-slate-700">{selectedStudentForView.createdDate}</span>
              </div>
            </div>

            <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
              <button
                onClick={() => window.print()}
                className="px-5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Record</span>
              </button>
              <button
                onClick={() => setSelectedStudentForView(null)}
                className="px-5 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
