import { db, collection, doc, getDocs, updateDoc } from '../firebase';

/**
 * Utility to transfer all students registered under Shurapur / Shorapur / Surapur 
 * to Shahapur, both in local storage caches and in live Firestore collections.
 */
export async function transferShurapurToShahapur() {
  const targetOld = ['shurapur', 'shorapur', 'surapur'];

  const isMatch = (str) => {
    if (!str || typeof str !== 'string') return false;
    const lower = str.trim().toLowerCase();
    return targetOld.some(old => lower.includes(old));
  };

  let localUpdated = false;

  // 1. Update Local Storage Caches
  const cacheKeys = [
    'sle_students_cache',
    'sle_coaching_students_cache',
    'sle_applications_cache',
    'sle_registered_halltickets',
    'sle_franchisees_cache'
  ];

  const branchFields = [
    'trainingCenter',
    'trustBranch',
    'branchName',
    'franchiseName',
    'place',
    'city',
    'location',
    'centerName',
    'center',
    'examCenter',
    'name'
  ];

  for (const key of cacheKeys) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      let parsed = JSON.parse(raw);
      let keyChanged = false;

      if (Array.isArray(parsed)) {
        parsed = parsed.map(item => {
          if (!item || typeof item !== 'object') return item;
          let itemMod = false;
          const updated = { ...item };

          for (const field of branchFields) {
            if (isMatch(updated[field])) {
              updated[field] = 'Shahapur';
              itemMod = true;
            }
          }

          if (itemMod) keyChanged = true;
          return updated;
        });

        if (keyChanged) {
          localStorage.setItem(key, JSON.stringify(parsed));
          localUpdated = true;
        }
      }
    } catch (err) {
      console.warn(`Error updating local cache key ${key}:`, err);
    }
  }

  // 2. Update Live Firestore Database Collections
  if (db) {
    const collectionsToMigrate = ['students', 'applications', 'coaching_students', 'franchisees', 'branches'];
    for (const colName of collectionsToMigrate) {
      try {
        const snap = await getDocs(collection(db, colName));
        for (const docSnap of snap.docs) {
          const data = docSnap.data();
          if (!data) continue;

          const updates = {};
          let needsUpdate = false;

          for (const field of branchFields) {
            if (isMatch(data[field])) {
              updates[field] = 'Shahapur';
              needsUpdate = true;
            }
          }

          if (needsUpdate) {
            try {
              await updateDoc(doc(db, colName, docSnap.id), updates);
              console.log(`[Transfer Success] Migrated document ${docSnap.id} in collection ${colName} to Shahapur`);
            } catch (uErr) {
              console.warn(`Error updating Firestore doc ${docSnap.id} in ${colName}:`, uErr);
            }
          }
        }
      } catch (colErr) {
        console.warn(`Error scanning collection ${colName} for Shurapur transfer:`, colErr);
      }
    }
  }

  return localUpdated;
}

/**
 * Branch fields that store branch/location information on student/application records
 */
export const STUDENT_BRANCH_FIELDS = [
  'trainingCenter',
  'trustBranch',
  'branchName',
  'franchiseName',
  'place',
  'city',
  'location',
  'centerName',
  'center',
  'examCenter',
];

/**
 * Collections that contain student/application records
 */
export const STUDENT_COLLECTIONS = ['students', 'applications', 'coaching_students'];

/**
 * Cache keys used to store student/application data in localStorage
 */
export const STUDENT_CACHE_KEYS = [
  'sle_students_cache',
  'sle_coaching_students_cache',
  'sle_applications_cache',
  'sle_registered_halltickets',
];

/**
 * Search for students in a given branch (from Firestore + localStorage caches)
 * @param {string} branchName - The branch name to search for
 * @returns {Promise<{students: Array, total: number}>}
 */
export async function fetchStudentsInBranch(branchName) {
  const targetLower = branchName.trim().toLowerCase();
  const students = [];
  const seenIds = new Set();

  const isBranchMatch = (val) => {
    if (!val || typeof val !== 'string') return false;
    return val.trim().toLowerCase() === targetLower;
  };

  const getBranchValue = (data) => {
    for (const field of STUDENT_BRANCH_FIELDS) {
      if (data[field]) return data[field];
    }
    return null;
  };

  // 1. Firestore collections
  if (db) {
    for (const colName of STUDENT_COLLECTIONS) {
      try {
        const snap = await getDocs(collection(db, colName));
        snap.forEach(docSnap => {
          const data = docSnap.data();
          if (!data) return;
          const matchesAnyField = STUDENT_BRANCH_FIELDS.some(f => isBranchMatch(data[f]));
          if (matchesAnyField && !seenIds.has(docSnap.id)) {
            seenIds.add(docSnap.id);
            students.push({
              id: docSnap.id,
              _collection: colName,
              _source: 'firestore',
              currentBranch: getBranchValue(data) || branchName,
              ...data,
            });
          }
        });
      } catch (e) {
        console.warn(`[fetchStudentsInBranch] Error scanning ${colName}:`, e);
      }
    }
  }

  // 2. LocalStorage caches (fallback / supplement)
  for (const key of STUDENT_CACHE_KEYS) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) continue;
      parsed.forEach(item => {
        if (!item || typeof item !== 'object') return;
        const matchesAnyField = STUDENT_BRANCH_FIELDS.some(f => isBranchMatch(item[f]));
        const itemId = item.id || item.registrationNo || item.admissionNo || item.admNo || item.appNumber;
        if (matchesAnyField && itemId && !seenIds.has(itemId)) {
          seenIds.add(itemId);
          students.push({
            ...item,
            id: itemId,
            _collection: key,
            _source: 'localStorage',
            currentBranch: getBranchValue(item) || branchName,
          });
        }
      });
    } catch (e) {
      console.warn(`[fetchStudentsInBranch] Error reading cache ${key}:`, e);
    }
  }

  return { students, total: students.length };
}

/**
 * Transfer students from one branch to another
 * @param {string[]} studentIds - Array of student IDs to transfer (or [] for ALL)
 * @param {string} fromBranch - Source branch name
 * @param {string} toBranch - Destination branch name
 * @param {string[]} [collections] - Firestore collections to update
 * @returns {Promise<{success: boolean, transferred: number, errors: string[], log: string[]}>}
 */
export async function transferStudentsBranch(studentIds, fromBranch, toBranch, collections = STUDENT_COLLECTIONS) {
  if (!fromBranch || !toBranch) {
    return { success: false, transferred: 0, errors: ['Source and destination branch are required.'], log: [] };
  }
  if (fromBranch.trim().toLowerCase() === toBranch.trim().toLowerCase()) {
    return { success: false, transferred: 0, errors: ['Source and destination branch cannot be the same.'], log: [] };
  }

  const fromLower = fromBranch.trim().toLowerCase();
  const log = [];
  const errors = [];
  let transferred = 0;

  const shouldTransfer = (data) => {
    return STUDENT_BRANCH_FIELDS.some(f => {
      if (!data[f] || typeof data[f] !== 'string') return false;
      return data[f].trim().toLowerCase() === fromLower;
    });
  };

  const buildUpdate = (data) => {
    const updates = {
      transferredAt: new Date().toISOString(),
      transferredFrom: fromBranch,
      transferredTo: toBranch,
    };
    STUDENT_BRANCH_FIELDS.forEach(f => {
      if (data[f] && typeof data[f] === 'string' && data[f].trim().toLowerCase() === fromLower) {
        updates[f] = toBranch;
      }
    });
    return updates;
  };

  const isTargetStudent = (id) => {
    if (!studentIds || studentIds.length === 0) return true; // Transfer ALL
    return studentIds.includes(id);
  };

  // 1. Update Firestore
  if (db) {
    for (const colName of collections) {
      try {
        const snap = await getDocs(collection(db, colName));
        for (const docSnap of snap.docs) {
          if (!isTargetStudent(docSnap.id)) continue;
          const data = docSnap.data();
          if (!data || !shouldTransfer(data)) continue;
          try {
            const updates = buildUpdate(data);
            await updateDoc(doc(db, colName, docSnap.id), updates);
            const name = data.fullName || data.studentName || data.candidateName || data.name || docSnap.id;
            log.push(`Transferred: ${name} (${docSnap.id}) in ${colName}`);
            transferred++;
          } catch (uErr) {
            const errMsg = `Error updating ${docSnap.id} in ${colName}: ${uErr?.message || 'update failed'}`;
            errors.push(errMsg);
            log.push(errMsg);
          }
        }
      } catch (colErr) {
        const errMsg = `Failed to scan collection "${colName}": ${colErr?.message || 'unknown error'}`;
        errors.push(errMsg);
        log.push(errMsg);
      }
    }
  }

  // 2. Update localStorage caches
  for (const key of STUDENT_CACHE_KEYS) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      let parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) continue;
      let changed = false;

      parsed = parsed.map(item => {
        if (!item || typeof item !== 'object') return item;
        const itemId = item.id || item.registrationNo || item.admissionNo || item.admNo || item.appNumber;
        if (!isTargetStudent(itemId)) return item;
        if (!shouldTransfer(item)) return item;
        const updates = buildUpdate(item);
        changed = true;
        return { ...item, ...updates };
      });

      if (changed) {
        localStorage.setItem(key, JSON.stringify(parsed));
        log.push(`Updated localStorage cache: ${key}`);
      }
    } catch (e) {
      const errMsg = `Failed to update localStorage key "${key}": ${e?.message}`;
      errors.push(errMsg);
      log.push(errMsg);
    }
  }

  return {
    success: errors.length === 0 || transferred > 0,
    transferred,
    errors,
    log,
  };
}
