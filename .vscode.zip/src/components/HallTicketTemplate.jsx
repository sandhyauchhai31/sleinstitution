import React, { useEffect, useState } from 'react';
import { Printer } from 'lucide-react';
import { getCourseFullName } from '../utils/courseManager';

// A5-landscape dimensions at 96 dpi
const DOC_W = 794;   // 210 mm
const DOC_H = 562;   // ~148 mm  (A5 landscape)
const SCALE = 0.72;

export default function HallTicketTemplate({ initialData, showControls = false }) {

  const build = (d) => ({
    admNo:          d?.admNo          || d?.admissionNo    || d?.registrationNo || '',
    htNo:           d?.htNo           || d?.rollNo         || d?.examRollNo     || '',
    candidateName:  d?.candidateName  || d?.name           || d?.fullName       || d?.studentName || '',
    fatherName:     d?.fatherName     || d?.parentName     || d?.guardianName   || '',
    courseCode:     getCourseFullName(d?.course         || d?.courseName     || d?.courseTitle    || d?.courseCode  || d?.coachingPlan || d?.program || d?.selectedClass || ''),
    trainingCenter: d?.trainingCenter || d?.trustBranch    || d?.examCenter     || d?.franchiseName || d?.branchName || d?.place || '',
    examDate:       d?.examDate       || d?.date           || '2026 Feb, 8',
    examTime:       d?.examTime       || d?.time           || '10:00 AM to 1:00 PM',
    photoUrl:       d?.photoUrl       || d?.photoPreview   || d?.photo          || d?.candidatePhoto || '',
    examPin:        d?.examPin        || '',
    examId:         d?.examId         || '',
  });

  const [data, setData] = useState(() => build(initialData));
  useEffect(() => { if (initialData) setData(build(initialData)); }, [initialData]);

  const handlePrint = () => {
    const orig = document.body.style.minWidth;
    document.body.style.minWidth = `${DOC_W}px`;
    window.print();
    setTimeout(() => { document.body.style.minWidth = orig; }, 1500);
  };

  const docContent = (
    <>
      {/* Outer red border frame */}
      <div style={{
        border: '3px solid #b91c1c',
        margin: '4px',
        position: 'relative',
        zIndex: 1,
        display: 'flex',
        flexDirection: 'column',
        flex: 1,
        overflow: 'hidden',
        borderRadius: '4px',
      }}>

        {/* HEADER: Logo + Institution Info + Photo */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '14px',
          padding: '10px 18px 8px',
          borderBottom: '1px dashed #fca5a5',
        }}>
          {/* SLES Logo */}
          <img
            src="/logo-2.png"
            alt="SLES Logo"
            style={{ width: '68px', height: '68px', objectFit: 'contain', flexShrink: 0 }}
          />

          {/* Institution Name + HALL TICKET badge */}
          <div style={{ flex: 1, textAlign: 'center' }}>
            <div style={{
              fontSize: '17px', fontWeight: 900, color: '#7f1d1d',
              letterSpacing: '0.04em', textTransform: 'uppercase',
              fontFamily: 'Georgia, serif', lineHeight: 1.2,
            }}>
              S.L.E.S. COMPUTER SAKSHARATA ABHIYAN (R)
            </div>
            <div style={{ fontSize: '9px', fontWeight: 600, color: '#374151', fontFamily: 'sans-serif', marginTop: '3px' }}>
              Regd. Under the govt. of India
            </div>
            <div style={{ fontSize: '9px', fontWeight: 600, color: '#374151', fontFamily: 'sans-serif' }}>
              A Non-Profit Social Service Oriented Society Regd.
            </div>
            <div style={{
              display: 'inline-block',
              marginTop: '6px',
              backgroundColor: '#b91c1c',
              color: '#ffffff',
              fontSize: '11px',
              fontWeight: 900,
              letterSpacing: '0.18em',
              padding: '3px 22px',
              borderRadius: '3px',
              fontFamily: 'sans-serif',
              textTransform: 'uppercase',
            }}>
              HALL TICKET
            </div>
          </div>

          {/* Candidate Photo */}
          <div style={{
            width: '72px', height: '88px',
            border: '1.5px solid #b91c1c',
            borderRadius: '2px',
            overflow: 'hidden',
            flexShrink: 0,
            backgroundColor: '#f8fafc',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
            {data.photoUrl ? (
              <img
                src={data.photoUrl}
                alt={data.candidateName}
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                onError={(e) => { e.target.style.display = 'none'; }}
              />
            ) : (
              <div style={{
                fontSize: '8px', color: '#94a3b8', textAlign: 'center',
                fontFamily: 'sans-serif', padding: '4px',
              }}>
                PHOTO
              </div>
            )}
          </div>
        </div>

        {/* STUDENT INFO GRID */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '0',
          padding: '8px 18px 6px',
          borderBottom: '1px dashed #fca5a5',
          fontSize: '10.5px',
          fontFamily: 'sans-serif',
        }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
            <InfoRow label="Stud. Name"  value={data.candidateName} bold />
            <InfoRow label="Exam. No"    value={data.htNo} />
            <InfoRow label="Father Name" value={data.fatherName} />
            <InfoRow label="Branch"      value={data.trainingCenter} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '5px', paddingLeft: '24px' }}>
            <InfoRow label="Registration No" value={data.admNo} />
            <InfoRow label="Course"          value={data.courseCode} bold />
            {data.examPin && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginTop: '2px' }}>
                <span style={{ color: '#374151', fontWeight: 600, whiteSpace: 'nowrap', minWidth: '82px', fontSize: '10.5px', fontFamily: 'sans-serif' }}>Exam PIN:</span>
                <span style={{
                  background: '#7f1d1d',
                  color: '#fff',
                  fontWeight: 900,
                  fontFamily: 'monospace',
                  fontSize: '11px',
                  letterSpacing: '0.25em',
                  padding: '1px 6px',
                  borderRadius: '4px',
                }}>{data.examPin}</span>
              </div>
            )}
          </div>
        </div>

        {/* EXAM SCHEDULE TABLE */}
        <div style={{ padding: '8px 14px 6px' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '10px', fontFamily: 'sans-serif' }}>
            <thead>
              <tr style={{ color: '#b91c1c' }}>
                {['Exam / Course', 'Center', 'Date', 'Time'].map((h) => (
                  <th key={h} style={{
                    fontWeight: 700, textAlign: 'left', padding: '3px 8px',
                    borderBottom: '1px solid #fca5a5',
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr style={{ borderBottom: '1px dashed #fca5a5' }}>
                <td style={{ padding: '5px 8px', fontWeight: 600, color: '#1e293b' }}>{data.courseCode || '—'}</td>
                <td style={{ padding: '5px 8px', color: '#374151' }}>{data.trainingCenter || '—'}</td>
                <td style={{ padding: '5px 8px', color: '#374151' }}>{data.examDate || '—'}</td>
                <td style={{ padding: '5px 8px', color: '#374151' }}>{data.examTime}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div style={{ flex: 1 }} />

        {/* SIGNATURE ROW */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'flex-end',
          padding: '6px 44px 12px',
          borderTop: '1px dashed #fca5a5',
        }}>
          <SigBlock label="Student Sign" />
          <SigBlock label="Center Head Sign" />
          <div style={{ textAlign: 'center' }}>
            <div style={{
              fontSize: '8px', fontWeight: 600, color: '#374151',
              fontFamily: 'sans-serif', lineHeight: 1.5, marginBottom: '2px',
            }}>
              <div>Managing Director</div>
              <div>Soft Line Education Society</div>
              <div>S.L.E.S. Institute.</div>
            </div>
            <div style={{ width: '100px', borderBottom: '1.5px solid #374151', margin: '4px auto 3px' }} />
            <div style={{
              fontSize: '10px', fontWeight: 900, fontStyle: 'italic',
              color: '#1a1a6e', fontFamily: 'Georgia, serif',
            }}>Director Sign</div>
          </div>
        </div>

      </div>
    </>
  );

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>

      {showControls && (
        <div className="print:hidden flex items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-md mb-4">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-600 animate-pulse inline-block"></span>
            <span className="text-sm font-bold text-slate-800">Hall Ticket Preview</span>
          </div>
          <button
            onClick={handlePrint}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-rose-700 hover:bg-rose-800 text-white flex items-center gap-2 transition shadow-sm cursor-pointer"
          >
            <Printer className="w-4 h-4" /> Print Hall Ticket
          </button>
        </div>
      )}

      {/* Screen preview wrapper — clipped to scaled visual size */}
      <div
        id="hallticket-preview-wrapper"
        style={{
          width: `${DOC_W * SCALE}px`,
          height: `${DOC_H * SCALE}px`,
          overflow: 'hidden',
          margin: '0 auto',
          boxShadow: '0 8px 32px rgba(0,0,0,0.18)',
          borderRadius: '2px',
        }}
      >
        <div
          id="official-hallticket-document"
          style={{
            width: `${DOC_W}px`,
            height: `${DOC_H}px`,
            transform: `scale(${SCALE})`,
            transformOrigin: 'top left',
            backgroundColor: '#ffffff',
            border: '4px solid #b91c1c',
            display: 'flex',
            flexDirection: 'column',
            position: 'relative',
            overflow: 'hidden',
            fontFamily: 'sans-serif',
            boxSizing: 'border-box',
          }}
        >
          {docContent}
        </div>
      </div>

      <style>{`
        @media print {
          /* A4 portrait — one page only */
          @page {
            size: A4 portrait;
            margin: 0;
          }
          html {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          html, body {
            width: 794px !important;
            height: 1123px !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: hidden !important;
            background: #ffffff !important;
          }

          /* Hide everything on the page */
          body * { visibility: hidden !important; }

          /* Zero-out the preview wrapper so it takes NO page space */
          #hallticket-preview-wrapper {
            width: 0 !important;
            height: 0 !important;
            overflow: visible !important;
            box-shadow: none !important;
            margin: 0 !important;
            padding: 0 !important;
          }

          /* Show only the actual ticket document */
          #official-hallticket-document,
          #official-hallticket-document * { visibility: visible !important; }

          /* Position ticket at top of A4 page, no transform */
          #official-hallticket-document {
            position: fixed !important;
            /* Centre horizontally: (794 - 700) / 2 = 47px */
            left: 47px !important;
            top: 40px !important;
            width: 700px !important;
            height: ${DOC_H}px !important;
            transform: none !important;
            transform-origin: unset !important;
            box-sizing: border-box !important;
            margin: 0 !important;
            box-shadow: none !important;
            border-radius: 0 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          .print\\:hidden { display: none !important; }
        }
      `}</style>
    </div>
  );
}

function InfoRow({ label, value, bold }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: '4px' }}>
      <span style={{ color: '#374151', fontWeight: 600, whiteSpace: 'nowrap', minWidth: '82px' }}>
        {label}:
      </span>
      <span style={{
        fontWeight: bold ? 800 : 600,
        color: bold ? '#7f1d1d' : '#111827',
        textTransform: 'uppercase',
        fontSize: '10.5px',
      }}>
        {value || '\u2014'}
      </span>
    </div>
  );
}

function SigBlock({ label }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ width: '90px', borderBottom: '1.5px solid #374151', margin: '0 auto 4px' }} />
      <div style={{
        fontSize: '10px', fontWeight: 900, fontStyle: 'italic',
        color: '#1a1a6e', fontFamily: 'Georgia, serif',
      }}>{label}</div>
    </div>
  );
}
